using System;
using System.Collections.Generic;


public class Car {

    public int id;
    public List<Street> streets = new List<Street>();

}